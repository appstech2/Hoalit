package com.bhh76.nkjjiuhhh;
import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class AddTransactionActivity extends AppCompatActivity {
    DrawerLayout drawerLayout;
    String selectedDate = "";
    private static final String CHANNEL_ID = "transactions_channel";
    boolean initialDataLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_transaction);
        
        createNotificationChannel();
        listenForNewTransactions();

        drawerLayout = findViewById(R.id.drawer_layout);
        EditText etAmount = findViewById(R.id.etAmount);
        EditText etDescription = findViewById(R.id.etDescription);
        EditText etDate = findViewById(R.id.etDate);

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        selectedDate = sdf.format(cal.getTime());
        etDate.setText(selectedDate);

        etDate.setOnClickListener(v -> {
            new DatePickerDialog(this, (view, y, m, d) -> {
                selectedDate = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d);
                etDate.setText(selectedDate);
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
        });

        findViewById(R.id.btnSave).setOnClickListener(v -> {
            String amt = etAmount.getText().toString();
            if(amt.isEmpty()) return;
            DatabaseReference db = FirebaseDatabase.getInstance().getReference("Transactions");
            String id = db.push().getKey();
            String user = FirebaseAuth.getInstance().getCurrentUser().getEmail();
            Transaction t = new Transaction(id, amt, etDescription.getText().toString(), selectedDate, user);
            db.child(id).setValue(t);
            etAmount.setText(""); etDescription.setText("");
            Toast.makeText(this, "تم الحفظ بنجاح", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btnReportsDirect).setOnClickListener(v -> startActivity(new Intent(this, ReportsActivity.class)));
        findViewById(R.id.btnOpenDrawer).setOnClickListener(v -> drawerLayout.openDrawer(Gravity.RIGHT));
    }

    private void listenForNewTransactions() {
        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Transactions");
        String currentUserEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();
        db.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot snapshot, String previousChildName) {
                if (!initialDataLoaded) return; 
                Transaction t = snapshot.getValue(Transaction.class);
                if (t != null && !t.userEmail.equals(currentUserEmail)) {
                    showNotification("حوالة جديدة من: " + t.userEmail, "المبلغ: " + t.amount + " - " + t.note);
                }
            }
            @Override public void onChildChanged(DataSnapshot s, String p) {}
            @Override public void onChildRemoved(DataSnapshot s) {}
            @Override public void onChildMoved(DataSnapshot s, String p) {}
            @Override public void onCancelled(DatabaseError e) {}
        });
        db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) { initialDataLoaded = true; }
            @Override public void onCancelled(DatabaseError error) {}
        });
    }

    private void showNotification(String title, String message) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);
        nm.notify((int) System.currentTimeMillis(), builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "حوالات جديدة", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
}