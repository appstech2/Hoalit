package com.bhh76.nkjjiuhhh;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import com.google.firebase.database.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class ReportsActivity extends AppCompatActivity {
    RecyclerView rv;
    TransactionAdapter adapter;
    ArrayList<Transaction> fullList = new ArrayList<>();
    ArrayList<Transaction> displayList = new ArrayList<>();
    TextView tvTotalCount, tvTotalAmount;
    String filterDate = "", searchQuery = "";
    DatabaseReference db = FirebaseDatabase.getInstance().getReference("Transactions");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);
        rv = findViewById(R.id.rvReports);
        tvTotalCount = findViewById(R.id.tvTotalCount);
        tvTotalAmount = findViewById(R.id.tvTotalAmount);
        EditText etDate = findViewById(R.id.etFilterDate);
        EditText etSearch = findViewById(R.id.etSearch);

        filterDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        etDate.setText(filterDate);

        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TransactionAdapter();
        rv.setAdapter(adapter);

        etDate.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, y, m, d) -> {
                filterDate = String.format(Locale.US, "%04d-%02d-%02d", y, m+1, d);
                etDate.setText(filterDate);
                applyFilters(); 
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s.toString().toLowerCase();
                applyFilters();
            }
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        db.addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot ss) {
                fullList.clear();
                for(DataSnapshot d : ss.getChildren()) {
                    Transaction t = d.getValue(Transaction.class);
                    if(t != null) fullList.add(t);
                }
                applyFilters();
            }
            @Override public void onCancelled(DatabaseError e) {}
        });
    }

    void applyFilters() {
        displayList.clear();
        double totalSum = 0;
        for(Transaction t : fullList) {
            boolean matchesDate = filterDate.isEmpty() || t.date.equals(filterDate);
            boolean matchesSearch = t.note.toLowerCase().contains(searchQuery) || t.amount.contains(searchQuery);
            if(matchesDate && matchesSearch) {
                displayList.add(t);
                try { totalSum += Double.parseDouble(t.amount); } catch(Exception e) {}
            }
        }
        adapter.notifyDataSetChanged();
        tvTotalCount.setText("العدد: " + displayList.size());
        tvTotalAmount.setText(String.format(Locale.US, "الإجمالي: %.2f $", totalSum));
    }

    class TransactionAdapter extends RecyclerView.Adapter<VH> {
        @Override public VH onCreateViewHolder(ViewGroup p, int vt) {
            return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_transaction, p, false));
        }
        @Override public void onBindViewHolder(VH h, int i) {
            Transaction t = displayList.get(i);
            h.amt.setText(t.amount + " $");
            h.note.setText(t.note);
            h.user.setText("بواسطة: " + t.userEmail);
            h.date.setText(t.date);

            // رسالة تأكيد الحذف
            h.btnDelete.setOnClickListener(v -> {
                new AlertDialog.Builder(ReportsActivity.this)
                    .setTitle("تأكيد الحذف")
                    .setMessage("هل تريد حذف هذه الحوالة فعلاً؟")
                    .setPositiveButton("نعم، حذف", (dialog, which) -> db.child(t.id).removeValue())
                    .setNegativeButton("إلغاء", null)
                    .show();
            });

            // نافذة التعديل الشاملة
            h.btnEdit.setOnClickListener(v -> {
                LinearLayout layout = new LinearLayout(ReportsActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL);
                layout.setPadding(50, 40, 50, 10);

                final EditText editAmount = new EditText(ReportsActivity.this);
                editAmount.setHint("تعديل المبلغ");
                editAmount.setText(t.amount);
                layout.addView(editAmount);

                final EditText editNote = new EditText(ReportsActivity.this);
                editNote.setHint("تعديل البيان");
                editNote.setText(t.note);
                layout.addView(editNote);

                final EditText editDate = new EditText(ReportsActivity.this);
                editDate.setHint("تعديل التاريخ");
                editDate.setText(t.date);
                editDate.setFocusable(false);
                editDate.setOnClickListener(view -> {
                    Calendar c = Calendar.getInstance();
                    new DatePickerDialog(ReportsActivity.this, (dp, y, m, d) -> {
                        editDate.setText(String.format(Locale.US, "%04d-%02d-%02d", y, m+1, d));
                    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
                });
                layout.addView(editDate);

                new AlertDialog.Builder(ReportsActivity.this)
                    .setTitle("تعديل الحوالة")
                    .setView(layout)
                    .setPositiveButton("تحديث البيانات", (dialog, which) -> {
                        HashMap<String, Object> map = new HashMap<>();
                        map.put("amount", editAmount.getText().toString());
                        map.put("note", editNote.getText().toString());
                        map.put("date", editDate.getText().toString());
                        db.child(t.id).updateChildren(map);
                    })
                    .setNegativeButton("إلغاء", null)
                    .show();
            });
        }
        @Override public int getItemCount() { return displayList.size(); }
    }
    class VH extends RecyclerView.ViewHolder {
        TextView amt, note, date, user; ImageButton btnEdit, btnDelete;
        VH(View v) { super(v);
            amt = v.findViewById(R.id.txtAmount); note = v.findViewById(R.id.txtNote);
            date = v.findViewById(R.id.txtDate); user = v.findViewById(R.id.txtUser);
            btnEdit = v.findViewById(R.id.btnEdit); btnDelete = v.findViewById(R.id.btnDelete);
        }
    }
}