package com.bhh76.nkjjiuhhh;
public class Transaction {
    public String id, amount, note, date, userEmail;
    public Transaction() {}
    public Transaction(String id, String amount, String note, String date, String userEmail) {
        this.id = id; this.amount = amount; this.note = note; this.date = date; this.userEmail = userEmail;
    }
}